The high-level design, at the present time, is as follows:
* Parse a WordPress eXtended RSS (WXR) file into a set of C# objects representing the layout of BlogML.
* Manipulate content as needed. (The initial release will probably not do any of this.)
* Serialize these objects as XML, creating a valid BlogML document.
* Post-processing tasks.

Some possible manipulations are:
* Parsing image links for future retrieval
* Translation of local hyperlinks (*)

Some possible post-processing tasks are:
* Downloading/saving local images
* Generating rewrite rules for Nginx / Apache / LightTPD between old posts and new ones (*)

(*) These tasks would be dependent on the URL rules of the intended destination for the generated BlogML file.
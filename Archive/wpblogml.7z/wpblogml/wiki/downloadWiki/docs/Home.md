**Project Description**
Converts WordPress Extended RSS (WXR) files to BlogML

This project aims to provide an easy way to convert the WordPress Extended RSS (WXR) format, which is what that platform provides as their export option, into BlogML, which is support by many different platforms.  It is a lightweight command-line executable that will work on Windows, as well as on Mac and Linux using [Mono](www.mono-project.com).

There is a [Design](Design) document that describes the processing taken on the WXR file.  There are several places where there are placeholders, but it presents what is possible.